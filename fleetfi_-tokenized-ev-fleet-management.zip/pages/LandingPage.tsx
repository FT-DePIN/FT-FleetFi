
import React from 'react';
import { Page } from '../types';

interface LandingPageProps {
  onNavigate: (page: Page) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-brand-charcoal text-white text-center p-4">
      <div className="max-w-3xl">
        <div className="flex justify-center items-center space-x-4 mb-6">
            <svg className="w-16 h-16 text-brand-green" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L2 7V17L12 22L22 17V7L12 2ZM12 4.43L19.57 9L12 13.57L4.43 9L12 4.43ZM3.5 9.94L11 14.7V20L3.5 15.82V9.94ZM13 14.7L20.5 9.94V15.82L13 20V14.7Z"/>
            </svg>
            <div>
                <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight">FleetFi</h1>
                <p className="text-brand-gray-medium">by Freenergy Tech</p>
            </div>
        </div>
        
        <h2 className="text-4xl md:text-5xl font-bold mb-4">
          Own a share of the future of clean mobility.
        </h2>
        <p className="text-lg md:text-xl text-brand-gray-medium mb-8">
          FleetFi by Freenergy Tech lets you co-own tokenized EVs, batteries, and charging infrastructure.
        </p>
        <button
          onClick={() => onNavigate(Page.InvestorDashboard)}
          className="bg-brand-yellow text-brand-charcoal font-bold py-3 px-8 rounded-lg text-lg hover:bg-yellow-400 transition-transform transform hover:scale-105"
        >
          Explore Dashboard
        </button>
      </div>
    </div>
  );
};
