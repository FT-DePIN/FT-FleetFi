
import React from 'react';
import { Asset } from '../types';
import { LeafIcon } from '../components/icons/LeafIcon';

interface ESGImpactPageProps {
  assets: Asset[];
}

const CO2_OFFSET_PER_SWAP = 0.0034; // in tons

export const ESGImpactPage: React.FC<ESGImpactPageProps> = ({ assets }) => {
  const totalSwaps = assets.reduce((sum, asset) => sum + asset.swaps, 0);
  const co2Avoided = totalSwaps * CO2_OFFSET_PER_SWAP;
  const monthlyGoal = 5; // tons
  const progress = Math.min((co2Avoided / monthlyGoal) * 100, 100);

  return (
    <div className="p-4 md:p-8 flex justify-center items-center min-h-[calc(100vh-80px)]">
      <div className="max-w-4xl w-full bg-brand-gray-dark p-8 rounded-2xl border border-brand-gray-dark/50 text-center">
        <div className="flex justify-center items-center mb-6">
            <LeafIcon className="w-12 h-12 text-brand-green mr-4" />
            <h2 className="text-4xl font-bold text-white">ESG / CO₂ Impact</h2>
        </div>
        
        <div className="bg-brand-charcoal p-8 rounded-xl my-8">
            <p className="text-lg text-brand-gray-medium">Total CO₂ Avoided</p>
            <p className="text-6xl font-extrabold text-brand-green my-2">
                {co2Avoided.toFixed(2)}
                <span className="text-4xl font-bold text-brand-gray-medium ml-2">tons</span>
            </p>
            <p className="text-sm text-brand-gray-medium">Based on {totalSwaps.toLocaleString()} total swaps.</p>
        </div>

        <div>
            <h3 className="text-xl font-bold text-white mb-4">Progress This Month</h3>
            <div className="w-full bg-brand-charcoal rounded-full h-4 mb-2">
                <div className="bg-brand-green h-4 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
            <p className="text-brand-gray-medium">You've offset {progress.toFixed(0)}% of the {monthlyGoal} ton goal for this month.</p>
        </div>

        <div className="mt-10">
            <button className="bg-brand-yellow text-brand-charcoal font-bold py-3 px-6 rounded-lg hover:bg-yellow-400 transition-colors mr-4">
                Export PDF Report (Dummy)
            </button>
             <p className="inline-block text-sm text-brand-gray-medium mt-4">Future integration with Carbon Marketplace.</p>
        </div>
      </div>
    </div>
  );
};
