
import React, { useState, useMemo } from 'react';
import { Asset, Token, Payout, Page } from '../types';
import { KPICard } from '../components/KPICard';
import { Modal } from '../components/Modal';
import { EarningsChart } from '../components/EarningsChart';
import { TagIcon } from '../components/icons/TagIcon';
import { CurrencyNairaIcon } from '../components/icons/CurrencyNairaIcon';
import { TrendingUpIcon } from '../components/icons/TrendingUpIcon';

interface InvestorDashboardProps {
  assets: Asset[];
  tokens: Token[];
  payouts: Payout[];
  onMintToken: (assetId: string, fraction: number, investAmount: number) => void;
}

const MintTokenForm: React.FC<{
    assets: Asset[];
    onMintToken: (assetId: string, fraction: number, investAmount: number) => void;
    onClose: () => void;
}> = ({ assets, onMintToken, onClose }) => {
    const [assetId, setAssetId] = useState<string>(assets[0]?.id || '');
    const [fraction, setFraction] = useState<number>(0.1);
    const [investAmount, setInvestAmount] = useState<number>(250000);
    const [isMinted, setIsMinted] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onMintToken(assetId, fraction, investAmount);
        setIsMinted(true);
    };

    if (isMinted) {
        const mintedAsset = assets.find(a => a.id === assetId);
        return (
            <div className="text-center">
                <div className="mx-auto w-16 h-16 flex items-center justify-center bg-brand-green rounded-full mb-4">
                    <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                </div>
                <h3 className="text-xl font-bold text-white">Token Minted Successfully!</h3>
                <p className="text-brand-gray-medium mt-2">
                    Token for {mintedAsset?.model} successfully minted.
                </p>
                <p className="text-brand-gray-medium">
                    ROI Projection: ₦{(investAmount * 0.45).toLocaleString()}/yr.
                </p>
                <button onClick={onClose} className="mt-6 w-full bg-brand-green text-white font-bold py-3 px-4 rounded-lg hover:bg-green-700 transition-colors">
                    Close
                </button>
            </div>
        );
    }
    
    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="asset" className="block text-sm font-medium text-brand-gray-medium">Select Asset</label>
                <select id="asset" value={assetId} onChange={e => setAssetId(e.target.value)} className="mt-1 block w-full bg-brand-gray-dark border border-brand-gray-dark/50 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-brand-green focus:border-brand-green">
                    {assets.filter(a => a.type !== 'Cabinet').map(asset => (
                        <option key={asset.id} value={asset.id}>{asset.model} ({asset.type})</option>
                    ))}
                </select>
            </div>
            <div>
                <label htmlFor="fraction" className="block text-sm font-medium text-brand-gray-medium">Fraction (%)</label>
                <input type="number" id="fraction" value={fraction * 100} onChange={e => setFraction(parseFloat(e.target.value) / 100)} max="100" min="1" step="1" className="mt-1 block w-full bg-brand-gray-dark border border-brand-gray-dark/50 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-brand-green focus:border-brand-green" />
            </div>
            <div>
                <label htmlFor="amount" className="block text-sm font-medium text-brand-gray-medium">Invest Amount (₦)</label>
                <input type="number" id="amount" value={investAmount} onChange={e => setInvestAmount(parseInt(e.target.value, 10))} min="50000" step="10000" className="mt-1 block w-full bg-brand-gray-dark border border-brand-gray-dark/50 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-brand-green focus:border-brand-green" />
            </div>
            <button type="submit" className="w-full bg-brand-yellow text-brand-charcoal font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors">
                Mint Token
            </button>
        </form>
    );
};


export const InvestorDashboard: React.FC<InvestorDashboardProps> = ({ assets, tokens, payouts, onMintToken }) => {
  const [isMintModalOpen, setIsMintModalOpen] = useState(false);

  const { monthlyROI, totalTokens } = useMemo(() => {
    const now = new Date();
    const currentMonthStr = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}`;
    const roi = payouts
      .filter(p => p.month === currentMonthStr)
      .reduce((sum, p) => sum + p.investorShare, 0);
    return { monthlyROI: roi, totalTokens: tokens.length };
  }, [payouts, tokens]);

  const assetsMap = useMemo(() => new Map(assets.map(asset => [asset.id, asset])), [assets]);

  return (
    <div className="p-4 md:p-8 space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white">Investor Dashboard</h2>
        <button onClick={() => setIsMintModalOpen(true)} className="bg-brand-green text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2">
          <TagIcon className="w-5 h-5" />
          <span>Mint New Token</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <KPICard icon={<TagIcon className="w-6 h-6 text-brand-yellow"/>} title="Tokens Owned" value={totalTokens} isAnimated />
        <KPICard icon={<CurrencyNairaIcon className="w-6 h-6 text-brand-yellow"/>} title="Monthly ROI" value={monthlyROI} prefix="₦" isAnimated />
        <KPICard icon={<TrendingUpIcon className="w-6 h-6 text-brand-yellow"/>} title="Simulated IRR" value={45} suffix="%" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3">
          <EarningsChart payouts={payouts} />
        </div>
        <div className="lg:col-span-2 bg-brand-gray-dark p-6 rounded-xl border border-brand-gray-dark/50">
          <h3 className="text-lg font-bold text-white mb-4">My Assets</h3>
          <div className="space-y-4 max-h-80 overflow-y-auto">
            {tokens.map(token => {
              const asset = assetsMap.get(token.assetId);
              if (!asset) return null;
              return (
                <div key={token.id} className="bg-brand-charcoal p-4 rounded-lg">
                  <div className="flex justify-between items-center">
                    <p className="font-semibold">{asset.model}</p>
                    <p className="text-sm text-brand-green font-bold">{(token.fraction * 100).toFixed(0)}% Owned</p>
                  </div>
                  <div className="text-xs text-brand-gray-medium mt-2 flex justify-between">
                    <span>SoH: {asset.soh}%</span>
                    <span>Swaps/mo: {asset.swaps}</span>
                    <span>Yield/mo: ₦{payouts.find(p => p.tokenId === token.id)?.investorShare.toLocaleString(undefined, { maximumFractionDigits: 0 }) || '...'}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      
      <Modal isOpen={isMintModalOpen} onClose={() => setIsMintModalOpen(false)} title="Mint New Ownership Token">
          <MintTokenForm assets={assets} onMintToken={onMintToken} onClose={() => setIsMintModalOpen(false)} />
      </Modal>

    </div>
  );
};
