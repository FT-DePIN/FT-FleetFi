import React from 'react';
import { Asset, SLXListing } from '../types';
import { TagIcon } from '../components/icons/TagIcon';

interface SLXMarketplaceProps {
  slxListings: SLXListing[];
  assets: Asset[];
}

export const SLXMarketplace: React.FC<SLXMarketplaceProps> = ({ slxListings, assets }) => {
  // Fix: Explicitly type the Map to resolve a type inference issue where asset was becoming 'unknown'.
  const assetsMap = new Map<string, Asset>(assets.map(asset => [asset.id, asset]));

  return (
    <div className="p-4 md:p-8">
      <div className="flex items-center space-x-4 mb-6">
        <TagIcon className="w-8 h-8 text-brand-yellow" />
        <h2 className="text-3xl font-bold text-white">SLX: Second-Life Marketplace</h2>
      </div>

      <p className="text-brand-gray-medium mb-6 max-w-2xl">
        Assets with a State of Health (SoH) below 50% are retired from the primary fleet and listed here for resale for second-life applications like solar energy storage.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {slxListings.length > 0 ? (
          slxListings.map(listing => {
            const asset = assetsMap.get(listing.assetId);
            if (!asset) return null;
            return (
              <div key={listing.assetId} className="bg-brand-gray-dark rounded-xl p-6 border border-brand-gray-dark/50 flex flex-col justify-between">
                <div>
                  <p className="font-bold text-xl text-white">{asset.model}</p>
                  <p className="text-sm text-brand-gray-medium mb-4">{listing.assetId}</p>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-brand-gray-medium">State of Health (SoH)</span>
                      <span className="font-semibold text-red-400">{listing.soh}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-brand-gray-medium">Salvage Value</span>
                      <span className="font-semibold text-brand-yellow">₦{listing.salvageValue.toLocaleString()}</span>
                    </div>
                     <div className="flex justify-between">
                      <span className="text-brand-gray-medium">Listed On</span>
                      <span className="font-semibold text-white">{listing.listedAt.toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
                <button className="mt-6 w-full bg-brand-green text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700 transition-colors">
                  Relist for Second-Life Use
                </button>
              </div>
            );
          })
        ) : (
          <div className="md:col-span-3 text-center py-16 bg-brand-gray-dark rounded-xl">
            <h3 className="text-xl font-bold text-white">No Assets on SLX</h3>
            <p className="text-brand-gray-medium mt-2">All assets are currently in good health.</p>
          </div>
        )}
      </div>
    </div>
  );
};