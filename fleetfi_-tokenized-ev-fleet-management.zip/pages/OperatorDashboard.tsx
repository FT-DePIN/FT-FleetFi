
import React from 'react';
import { Asset } from '../types';
import { SwapIcon } from '../components/icons/SwapIcon';
import { BatteryIcon } from '../components/icons/BatteryIcon';

interface OperatorDashboardProps {
  assets: Asset[];
  onSimulateSwap: (assetId: string) => void;
  onSimulateCharge: (assetId: string) => void;
}

const getSohColor = (soh: number) => {
    if (soh < 30) return 'bg-red-500';
    if (soh < 70) return 'bg-yellow-500';
    return 'bg-brand-green';
}

const getStatusClasses = (status: string) => {
    switch(status) {
        case 'Available': return 'bg-green-500/20 text-green-400';
        case 'In Use': return 'bg-blue-500/20 text-blue-400';
        case 'Charging': return 'bg-yellow-500/20 text-yellow-400';
        case 'Maintenance': return 'bg-red-500/20 text-red-400';
        default: return 'bg-gray-500/20 text-gray-400';
    }
}

const AssetCard: React.FC<{
    asset: Asset;
    onSimulateSwap: (assetId: string) => void;
    onSimulateCharge: (assetId: string) => void;
}> = ({ asset, onSimulateCharge, onSimulateSwap }) => (
    <div className="bg-brand-gray-dark rounded-xl p-4 border border-brand-gray-dark/50 flex flex-col justify-between">
        <div>
            <div className="flex justify-between items-start">
                <div>
                    <p className="font-bold text-white">{asset.model}</p>
                    <p className="text-xs text-brand-gray-medium">{asset.id}</p>
                </div>
                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusClasses(asset.status)}`}>
                    {asset.status}
                </span>
            </div>
            {asset.soh < 30 && (
                <div className="mt-2 text-xs bg-red-500/20 text-red-400 p-2 rounded-md flex items-center space-x-2">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                    <span>Maintenance Alert: SoH is critical.</span>
                </div>
            )}
            <div className="mt-4">
                <p className="text-sm text-brand-gray-medium mb-1">Battery SoH</p>
                <div className="w-full bg-brand-charcoal rounded-full h-2.5">
                    <div className={`${getSohColor(asset.soh)} h-2.5 rounded-full`} style={{ width: `${asset.soh}%` }}></div>
                </div>
                <p className="text-right text-sm font-bold mt-1">{asset.soh}%</p>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4 text-center">
                <div>
                    <p className="text-sm text-brand-gray-medium">Total Swaps</p>
                    <p className="font-bold text-xl text-white">{asset.swaps}</p>
                </div>
                <div>
                    <p className="text-sm text-brand-gray-medium">Daily Swaps</p>
                    <p className="font-bold text-xl text-white">{asset.dailySwaps}</p>
                </div>
            </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2">
            <button onClick={() => onSimulateSwap(asset.id)} className="bg-brand-yellow/20 text-brand-yellow py-2 px-3 rounded-lg text-sm font-semibold hover:bg-brand-yellow/40 transition-colors flex items-center justify-center space-x-2">
                <SwapIcon className="w-4 h-4"/>
                <span>Swap</span>
            </button>
            <button onClick={() => onSimulateCharge(asset.id)} className="bg-brand-green/20 text-brand-green py-2 px-3 rounded-lg text-sm font-semibold hover:bg-brand-green/40 transition-colors flex items-center justify-center space-x-2">
                <BatteryIcon className="w-4 h-4"/>
                <span>Charge</span>
            </button>
        </div>
    </div>
);


export const OperatorDashboard: React.FC<OperatorDashboardProps> = ({ assets, onSimulateCharge, onSimulateSwap }) => {
  return (
    <div className="p-4 md:p-8">
      <h2 className="text-3xl font-bold text-white mb-6">Operator Dashboard</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {assets.filter(a => a.type === 'EV').map(asset => (
          <AssetCard key={asset.id} asset={asset} onSimulateCharge={onSimulateCharge} onSimulateSwap={onSimulateSwap} />
        ))}
      </div>

       <div className="mt-8 bg-brand-gray-dark p-6 rounded-xl border border-brand-gray-dark/50">
          <h3 className="text-lg font-bold text-white mb-4">Live Telemetry Feed</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-brand-gray-light">
                <thead className="text-xs text-brand-gray-medium uppercase bg-brand-charcoal">
                    <tr>
                        <th scope="col" className="px-6 py-3">Asset ID</th>
                        <th scope="col" className="px-6 py-3">SoH</th>
                        <th scope="col" className="px-6 py-3">Status</th>
                        <th scope="col" className="px-6 py-3">Total Swaps</th>
                        <th scope="col" className="px-6 py-3">Location</th>
                    </tr>
                </thead>
                <tbody>
                    {assets.map((asset) => (
                        <tr key={asset.id} className="border-b border-brand-gray-dark/50 hover:bg-brand-charcoal">
                            <td className="px-6 py-4 font-medium whitespace-nowrap">{asset.id}</td>
                            <td className="px-6 py-4">{asset.soh}%</td>
                            <td className="px-6 py-4">
                                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusClasses(asset.status)}`}>
                                    {asset.status}
                                </span>
                            </td>
                            <td className="px-6 py-4">{asset.swaps}</td>
                            <td className="px-6 py-4">{asset.location}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
          </div>
        </div>
    </div>
  );
};
