
import { Asset, Token, Payout, SLXListing } from '../types';

const ASSET_COUNT = 5;
const INVESTOR_ID = 'user-001';

export const generateMockAssets = (): Asset[] => {
  const assets: Asset[] = [];
  for (let i = 1; i <= ASSET_COUNT; i++) {
    const isRetired = i === ASSET_COUNT;
    assets.push({
      id: `FT-EV-${100 + i}`,
      type: 'EV',
      model: `Freenergy Mover ${i}`,
      status: isRetired ? 'Maintenance' : i % 2 === 0 ? 'In Use' : 'Available',
      soh: isRetired ? 45 : Math.floor(Math.random() * 30) + 70,
      swaps: Math.floor(Math.random() * 500) + 100,
      location: `Lekki Phase ${i}`,
      originalValue: 3500000,
      dailySwaps: Math.floor(Math.random() * 5) + 2,
    });
  }
   assets.push({
      id: `FT-BATT-007`,
      type: 'Battery',
      model: `Freenergy PowerPack`,
      status: 'Available',
      soh: 98,
      swaps: 55,
      location: `Ikoyi Charging Hub`,
      originalValue: 800000,
      dailySwaps: 0,
   });
  return assets;
};

export const generateMockTokens = (assets: Asset[]): Token[] => {
  const tokens: Token[] = [];
  const investorAssets = assets.slice(0, 3);
  investorAssets.forEach((asset, index) => {
    const investAmount = (index + 1) * 250000;
    tokens.push({
      id: `TKN-${asset.id}-01`,
      investorId: INVESTOR_ID,
      assetId: asset.id,
      fraction: 0.1 * (index + 1),
      investAmount,
      roiProjection: investAmount * 0.45,
      mintedAt: new Date(new Date().setDate(new Date().getDate() - (30 * (index + 1)))),
    });
  });
  return tokens;
};

export const generateMockPayouts = (tokens: Token[]): Payout[] => {
  const payouts: Payout[] = [];
  const months = 6;
  const now = new Date();

  tokens.forEach(token => {
    for (let i = 0; i < months; i++) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthStr = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}`;
      const investorShare = (token.investAmount * (0.45 / 12)) * (Math.random() * 0.4 + 0.8);

      payouts.push({
        payoutId: `PAY-${token.id}-${monthStr}`,
        tokenId: token.id,
        month: monthStr,
        grossRevenue: investorShare / (token.fraction * 0.5),
        investorShare: investorShare
      });
    }
  });

  return payouts.sort((a, b) => a.month.localeCompare(b.month));
};


export const generateMockSLXListings = (assets: Asset[]): SLXListing[] => {
    return assets
        .filter(asset => asset.soh < 50)
        .map(asset => ({
            assetId: asset.id,
            soh: asset.soh,
            salvageValue: asset.originalValue * 0.2,
            listedAt: new Date(),
        }));
}

export const initialAssets = generateMockAssets();
export const initialTokens = generateMockTokens(initialAssets);
export const initialPayouts = generateMockPayouts(initialTokens);
export const initialSLXListings = generateMockSLXListings(initialAssets);
