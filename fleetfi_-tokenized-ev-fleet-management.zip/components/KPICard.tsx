
import React, { useState, useEffect } from 'react';

interface KPICardProps {
  icon: React.ReactNode;
  title: string;
  value: string | number;
  prefix?: string;
  suffix?: string;
  isAnimated?: boolean;
}

export const KPICard: React.FC<KPICardProps> = ({ icon, title, value, prefix = '', suffix = '', isAnimated = false }) => {
    const [displayValue, setDisplayValue] = useState(0);

    const numericValue = typeof value === 'string' ? parseFloat(value.replace(/,/g, '')) : value;

    useEffect(() => {
        if (!isAnimated || isNaN(numericValue)) return;

        let start = 0;
        const end = numericValue;
        if (start === end) return;

        const duration = 1000;
        const range = end - start;
        let current = start;
        const increment = end > start ? 1 : -1;
        const stepTime = Math.abs(Math.floor(duration / range));
        
        const timer = setInterval(() => {
            current += increment * Math.max(1, Math.floor(range / (duration/16)));
            if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
                current = end;
                clearInterval(timer);
            }
            setDisplayValue(current);
        }, 16);

        return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [value, isAnimated]);


  const formattedValue = isAnimated ? displayValue : numericValue;

  return (
    <div className="bg-brand-gray-dark p-6 rounded-xl border border-brand-gray-dark/50 flex items-center space-x-4">
      <div className="bg-brand-green/20 p-3 rounded-full">
        {icon}
      </div>
      <div>
        <p className="text-sm text-brand-gray-medium font-medium">{title}</p>
        <p className="text-2xl lg:text-3xl font-bold text-white">
          {prefix}
          {isNaN(formattedValue) ? value : formattedValue.toLocaleString(undefined, { maximumFractionDigits: 2 })}
          {suffix}
        </p>
      </div>
    </div>
  );
};
