
import React from 'react';
import { Payout } from '../types';
// Note: In a real project, you would `npm install recharts`
// For this environment, we assume it's available.
// If it is not, this will render nothing.
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface EarningsChartProps {
  payouts: Payout[];
}

export const EarningsChart: React.FC<EarningsChartProps> = ({ payouts }) => {
    if (typeof BarChart === 'undefined') {
        return <div className="text-center p-8 bg-brand-gray-dark rounded-xl">Charting library not available.</div>;
    }
  const monthlyData: { [key: string]: number } = {};

  payouts.forEach(payout => {
    if (!monthlyData[payout.month]) {
      monthlyData[payout.month] = 0;
    }
    monthlyData[payout.month] += payout.investorShare;
  });

  const chartData = Object.keys(monthlyData)
    .sort()
    .map(month => ({
      name: new Date(month + '-02').toLocaleString('default', { month: 'short' }), // Add day to avoid timezone issues
      Earnings: monthlyData[month],
    }));

  return (
    <div className="bg-brand-gray-dark p-6 rounded-xl border border-brand-gray-dark/50 h-96">
        <h3 className="text-lg font-bold text-white mb-4">Monthly Earnings</h3>
        <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#444" />
            <XAxis dataKey="name" stroke="#A0A0A0" />
            <YAxis stroke="#A0A0A0" tickFormatter={(value) => `₦${Number(value).toLocaleString()}`} />
            <Tooltip
                contentStyle={{ backgroundColor: '#1E1E1E', border: '1px solid #333' }}
                labelStyle={{ color: '#EFEFEF' }}
                formatter={(value) => [`₦${Number(value).toLocaleString()}`, 'Earnings']}
            />
            <Legend wrapperStyle={{ color: '#EFEFEF' }} />
            <Bar dataKey="Earnings" fill="#2F8F4A" radius={[4, 4, 0, 0]} />
            </BarChart>
        </ResponsiveContainer>
    </div>
  );
};
