
import React from 'react';
import { Page } from '../types';
import { ChartBarIcon } from './icons/ChartBarIcon';
import { CarIcon } from './icons/CarIcon';
import { LeafIcon } from './icons/LeafIcon';
import { TagIcon } from './icons/TagIcon';

interface HeaderProps {
  currentPage: Page;
  userRole: 'investor' | 'operator';
  onNavigate: (page: Page) => void;
  onSetUserRole: (role: 'investor' | 'operator') => void;
}

const NavItem: React.FC<{
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
      isActive
        ? 'bg-brand-green text-white'
        : 'text-brand-gray-medium hover:bg-brand-gray-dark hover:text-white'
    }`}
  >
    {icon}
    <span>{label}</span>
  </button>
);

export const Header: React.FC<HeaderProps> = ({ currentPage, userRole, onNavigate, onSetUserRole }) => {
  return (
    <header className="bg-brand-charcoal border-b border-brand-gray-dark p-4 flex justify-between items-center sticky top-0 z-50">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
            <svg className="w-8 h-8 text-brand-green" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L2 7V17L12 22L22 17V7L12 2ZM12 4.43L19.57 9L12 13.57L4.43 9L12 4.43ZM3.5 9.94L11 14.7V20L3.5 15.82V9.94ZM13 14.7L20.5 9.94V15.82L13 20V14.7Z"/>
            </svg>
            <h1 className="text-xl font-bold text-white">FleetFi</h1>
        </div>
        <nav className="hidden md:flex items-center space-x-2">
          <NavItem
            icon={<ChartBarIcon className="w-5 h-5" />}
            label="Investor Dashboard"
            isActive={currentPage === Page.InvestorDashboard}
            onClick={() => onNavigate(Page.InvestorDashboard)}
          />
          <NavItem
            icon={<CarIcon className="w-5 h-5" />}
            label="Operator Dashboard"
            isActive={currentPage === Page.OperatorDashboard}
            onClick={() => onNavigate(Page.OperatorDashboard)}
          />
          <NavItem
            icon={<LeafIcon className="w-5 h-5" />}
            label="ESG Impact"
            isActive={currentPage === Page.ESGImpact}
            onClick={() => onNavigate(Page.ESGImpact)}
          />
          <NavItem
            icon={<TagIcon className="w-5 h-5" />}
            label="SLX Marketplace"
            isActive={currentPage === Page.SLXMarketplace}
            onClick={() => onNavigate(Page.SLXMarketplace)}
          />
        </nav>
      </div>
      <div className="flex items-center space-x-4">
        <div className="bg-brand-gray-dark p-1 rounded-lg flex text-sm">
          <button
            onClick={() => onSetUserRole('investor')}
            className={`px-3 py-1 rounded-md transition-colors ${userRole === 'investor' ? 'bg-brand-green text-white' : 'text-brand-gray-medium'}`}
          >
            Investor
          </button>
          <button
            onClick={() => onSetUserRole('operator')}
            className={`px-3 py-1 rounded-md transition-colors ${userRole === 'operator' ? 'bg-brand-green text-white' : 'text-brand-gray-medium'}`}
          >
            Operator
          </button>
        </div>
      </div>
    </header>
  );
};
