
import React from 'react';
import { IconProps } from './IconProps';

export const LeafIcon: React.FC<IconProps> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M14.121 15.879A6 6 0 0112.025 10.5 6 6 0 0117.5 4.562c.313.313.613.638.904.975a6 6 0 01-5.282 10.342zM12.025 10.5a6 6 0 00-5.475 3.121M12.025 10.5a6 6 0 01-3.121 5.475m3.121-5.475L9 16.5" />
  </svg>
);
